document.addEventListener("DOMContentLoaded", () => {
  var a = document.getElementById("datatables-ajax");
  a && new DataTable(a, {
      ajax: "assets/data/datatables.json",
      processing: !0,
      columns: [
        { data: "company" },
        { data: "symbol" },
        { data: "price" },
        { data: "change" },
        { data: "volume" },
        { data: "market_cap" },
        { data: "rating" },
        {
          data: "status",
          render: (a, s, e) =>
            `<span class="badge badge-label badge-soft-${
              "Bullish" === a ? "success" : "danger"
            }">${a}</span>`,
        },
      ],
      language: {
        paginate: {
          first: '<i class="ti ti-chevrons-left"></i>',
          previous: '<i class="ti ti-chevron-left"></i>',
          next: '<i class="ti ti-chevron-right"></i>',
          last: '<i class="ti ti-chevrons-right"></i>',
        },
        lengthMenu: "_MENU_ Companies per page",
        info: 'Showing <span class="fw-semibold">_START_</span> to <span class="fw-semibold">_END_</span> of <span class="fw-semibold">_TOTAL_</span> Companies',
      },
    });
});
